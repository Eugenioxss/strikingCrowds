prompt --application/shared_components/user_interface/lovs/eba_ca_access_levels_access_level
begin
--   Manifest
--     EBA_CA_ACCESS_LEVELS.ACCESS_LEVEL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424569748445147056
,p_default_application_id=>800085
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CLARISABAZALDUA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38711915903776274209)
,p_lov_name=>'EBA_CA_ACCESS_LEVELS.ACCESS_LEVEL'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EBA_CA_ACCESS_LEVELS'
,p_return_column_name=>'ID'
,p_display_column_name=>'ACCESS_LEVEL'
,p_default_sort_column_name=>'ACCESS_LEVEL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15569362914963
);
wwv_flow_imp.component_end;
end;
/
