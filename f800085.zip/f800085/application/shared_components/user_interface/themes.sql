prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 800085
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424569748445147056
,p_default_application_id=>800085
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CLARISABAZALDUA'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(38677814800915478722)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'24.1'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(38677374208109478547)
,p_default_dialog_template=>wwv_flow_imp.id(38677369011880478545)
,p_error_template=>wwv_flow_imp.id(38677359070890478540)
,p_printer_friendly_template=>wwv_flow_imp.id(38677374208109478547)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(38677359070890478540)
,p_default_button_template=>wwv_flow_imp.id(38677724744677478612)
,p_default_region_template=>wwv_flow_imp.id(38677650954323478580)
,p_default_chart_template=>wwv_flow_imp.id(38677650954323478580)
,p_default_form_template=>wwv_flow_imp.id(38677650954323478580)
,p_default_reportr_template=>wwv_flow_imp.id(38677650954323478580)
,p_default_tabform_template=>wwv_flow_imp.id(38677650954323478580)
,p_default_wizard_template=>wwv_flow_imp.id(38677650954323478580)
,p_default_menur_template=>wwv_flow_imp.id(38677663338173478585)
,p_default_listr_template=>wwv_flow_imp.id(38677650954323478580)
,p_default_irr_template=>wwv_flow_imp.id(38677641175205478576)
,p_default_report_template=>wwv_flow_imp.id(38677689327478478596)
,p_default_label_template=>wwv_flow_imp.id(38677722277854478610)
,p_default_menu_template=>wwv_flow_imp.id(38677726320111478613)
,p_default_calendar_template=>wwv_flow_imp.id(38677726484112478613)
,p_default_list_template=>wwv_flow_imp.id(38677706022281478603)
,p_default_nav_list_template=>wwv_flow_imp.id(38677717979461478608)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(38677717979461478608)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(38677712433752478606)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(38677387156509478553)
,p_default_dialogr_template=>wwv_flow_imp.id(38677384356336478551)
,p_default_option_label=>wwv_flow_imp.id(38677722277854478610)
,p_default_required_label=>wwv_flow_imp.id(38677723518011478611)
,p_default_navbar_list_template=>wwv_flow_imp.id(38677712083383478606)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/24.1/')
,p_files_version=>65
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
